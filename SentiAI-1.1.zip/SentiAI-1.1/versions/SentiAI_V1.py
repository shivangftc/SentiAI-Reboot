import requests
import time
import os
import threading
import http.server
import socketserver
from dotenv import load_dotenv
from analyzer import analyze_sentiment
from trader import execute_trade

load_dotenv()

# --- CONFIGURATION ---
AV_API_KEY = os.getenv('AV_API_KEY')
TICKER = 'TSLA'  # Set your target stock

def run_dummy_server():
    """Satisfies Render's port check so the service stays 'Live'."""
    port = int(os.environ.get("PORT", 10000))
    handler = http.server.SimpleHTTPRequestHandler
    try:
        with socketserver.TCPServer(("0.0.0.0", port), handler) as httpd:
            print(f"📡 Dummy server live on port {port}")
            httpd.serve_forever()
    except Exception as e:
        print(f"Server error: {e}")

def get_live_news(symbol):
    """Fetches stock news using Alpha Vantage."""
    url = f'https://www.alphavantage.co/query?function=NEWS_SENTIMENT&tickers={symbol}&apikey={AV_API_KEY}'
    try:
        response = requests.get(url, timeout=10)
        data = response.json()
        if "feed" in data and len(data["feed"]) > 0:
            return data["feed"][0]['title']
    except Exception as e:
        print(f"❌ News API Error: {e}")
    return None

def main():
    threading.Thread(target=run_dummy_server, daemon=True).start()
    print(f"--- SentiAI Started: Tracking {TICKER} ---")
    
    while True:
        headline = get_live_news(TICKER)
        if headline:
            print(f"📰 Headline: {headline}")
            label, score = analyze_sentiment(headline)
            print(f"🧠 AI: {label.upper()} (Conf: {score:.2f})")
            execute_trade(TICKER, label, score)
        
        print("💤 Sleeping for 60 minutes...")
        time.sleep(3600)

if __name__ == "__main__":
    main()
